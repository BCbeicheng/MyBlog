package com.dtborad.myblog.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.dtborad.myblog.common.CommonErrorCode;
import com.dtborad.myblog.common.Result;
import com.dtborad.myblog.entity.Categories;
import com.dtborad.myblog.service.CategoryService;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/category")
@Slf4j
@Api("分类模块")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @GetMapping("/list")
    public Result<List<Categories>> getCategoriesList(){
        return Result.ofSuccess(categoryService.list());
    }

    @GetMapping("/{id}")
    public Result<Categories> getCategoryById(@PathVariable Integer id) {
        Categories categories = new Categories();
        try{
            if(id != null && id > 0){
                LambdaQueryWrapper<Categories> queryWrapper = new LambdaQueryWrapper<>();
                queryWrapper.eq(Categories::getCategoryid,id);
                categories = categoryService.getOne(queryWrapper);
            }
        }catch (Exception e) {
            return Result.ofFail(CommonErrorCode.INVALID_PARAM);
        }
        return Result.ofSuccess(categories);
    }
}
