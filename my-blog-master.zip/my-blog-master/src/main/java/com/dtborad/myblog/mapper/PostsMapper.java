package com.dtborad.myblog.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dtborad.myblog.entity.Posts;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface PostsMapper extends BaseMapper<Posts> {
}