package com.dtborad.myblog.service.impl;

import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dtborad.myblog.entity.Categories;
import com.dtborad.myblog.mapper.CategoriesMapper;
import com.dtborad.myblog.service.CategoryService;
import org.springframework.stereotype.Service;

@Service
public class CategoryServiceImpl extends ServiceImpl<CategoriesMapper, Categories> implements CategoryService {
}
