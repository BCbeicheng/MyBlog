package com.dtborad.myblog.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.dtborad.myblog.entity.Tags;

public interface TagService extends IService<Tags> {
}
