package com.dtborad.myblog.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 标签实体类
 */
@Data
@TableName("tags")
public class Tags implements Serializable {
    /**
     * @北城
     * 标签ID
     */
    //@TableField("TagID")
    @TableId(value = "TagID", type = IdType.AUTO)
    private Integer tagid;

    /**
     * @北城
     * 标签名称
     */
    @TableField("TagName")
    private String tagname;

    /**
     * @北城
     * 创建时间
     */
    @TableField("CreateTime")
    private Date createtime;

    /**
     * @北城
     * 序列化ID
     */
    private static final long serialVersionUID = 1L;
}
