package com.dtborad.myblog.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.dtborad.myblog.entity.Categories;

public interface CategoryService extends IService<Categories> {
}
