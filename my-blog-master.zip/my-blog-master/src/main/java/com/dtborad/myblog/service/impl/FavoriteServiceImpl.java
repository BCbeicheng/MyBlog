package com.dtborad.myblog.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dtborad.myblog.entity.Favorites;
import com.dtborad.myblog.mapper.FavoritesMapper;
import com.dtborad.myblog.service.FavoriteService;
import org.springframework.stereotype.Service;

@Service
public class FavoriteServiceImpl extends ServiceImpl<FavoritesMapper, Favorites> implements FavoriteService {
}
