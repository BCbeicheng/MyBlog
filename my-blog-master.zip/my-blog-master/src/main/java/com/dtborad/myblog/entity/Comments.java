package com.dtborad.myblog.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 评论实体类
 */
@Data
@TableName("comments")
public class Comments implements Serializable {
    /**
     * @北城
     * 评论ID
     */
    //@TableField("CommentID")
    @TableId(value = "CommentID", type = IdType.AUTO)
    private Integer commentid;

    /**
     * @北城
     * 文章ID
     */
    @TableField("PostID")
    private Integer postid;

    /**
     * @北城
     * 评论者ID
     */
    @TableField("UserID")
    private Integer userid;

    /**
     * @北城
     * 评论时间
     */
    @TableField("CommentTime")
    private Date commenttime;

    /**
     * @北城
     * 评论内容
     */
    @TableField("CommentContent")
    private String commentcontent;

    /**
     * @北城
     * 序列化ID
     */
    private static final long serialVersionUID = 1L;
}
