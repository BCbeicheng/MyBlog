package com.dtborad.myblog.common;

public enum CommonErrorCode {
    OK(200, "成功"),

    BAD_REQUEST(400, "错误的请求"),
    UNAUTHORIZED(401, "未授权"),
    FORBIDDEN(403, "禁止访问"),
    NOT_FOUND(404, "资源未找到"),
    METHOD_NOT_ALLOWED(405, "方法不被允许"),
    CONFLICT(409, "资源冲突"),
    UNPROCESSABLE_ENTITY(422, "无法处理的实体"),

    // 5xx Server Error
    INTERNAL_SERVER_ERROR(500, "内部服务器错误"),
    NOT_IMPLEMENTED(501, "尚未实现"),
    SERVICE_UNAVAILABLE(503, "服务不可用"),

    // Custom Error Codes
    SUCCESS(200, "操作成功"),
    FAILURE(400, "操作失败"),
    INVALID_PARAM(400, "无效参数"),
    DATA_NOT_FOUND(404, "数据未找到"),
    DATA_CONFLICT(409, "数据冲突"),
    DATABASE_ERROR(500, "数据库错误"),
    IO_ERROR(500, "IO 错误"),
    TIMEOUT_ERROR(504, "请求超时"),
    LOGIN_FAIL(8888, "用户名或密码错误"),
    UNSUPPORTED_FILE_TYPES(9999, "不支持的文件类型");

    private final int code;
    private final String message;

    CommonErrorCode(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
