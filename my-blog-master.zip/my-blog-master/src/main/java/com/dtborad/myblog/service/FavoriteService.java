package com.dtborad.myblog.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.dtborad.myblog.entity.Favorites;

public interface FavoriteService extends IService<Favorites> {
}
