package com.dtborad.myblog.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 分类实体类
 */
@Data
@TableName("categories")
public class Categories implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * @北城
     * 分类ID
     */
    //@TableField("CategoryID")
    @TableId(value = "CategoryID", type = IdType.AUTO)
    private Integer categoryid;

    /**
     * @北城
     * 分类名称
     */
    @TableField("CategoryName")
    private String categoryname;

    /**
     * @北城
     * 父分类ID
     */
    @TableField("ParentCategoryID")
    private Integer parentcategoryid;

    /**
     * @北城
     * 创建时间
     */
    @TableField("CreateTime")
    private Date createtime;
}
