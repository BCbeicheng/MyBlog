package com.dtborad.myblog.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dtborad.myblog.entity.Users;
import com.dtborad.myblog.mapper.UsersMapper;
import com.dtborad.myblog.service.UserService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl extends ServiceImpl<UsersMapper, Users> implements UserService {

    @Autowired
    private UsersMapper usersMapper;

    @Override
    public Integer registerUser(Users user) {
        //Users newUser = new Users();
        int insert = 0;
        try {
            //首先校验用户是否已存在
            LambdaQueryWrapper<Users> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Users::getUsername, user.getUsername());
            Users originUser = usersMapper.selectOne(wrapper);
            if (originUser == null) {
                insert = usersMapper.insert(user);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return insert;
    }
}
