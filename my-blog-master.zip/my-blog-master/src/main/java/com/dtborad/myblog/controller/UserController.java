package com.dtborad.myblog.controller;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.dtborad.myblog.common.CommonErrorCode;
import com.dtborad.myblog.common.Result;
import com.dtborad.myblog.dto.UserDto;
import com.dtborad.myblog.entity.Users;
import com.dtborad.myblog.service.UserService;
import io.swagger.annotations.Api;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/user")
@Slf4j
@Api("用户模块")
@CrossOrigin(origins = "*")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping
    public Result<List<Users>> getUserAll() {
        List<Users> usersList = userService.list();
        return Result.ofSuccess(usersList);
    }

    @GetMapping("/{id}")
    public Result<Users> getUserById(@PathVariable Integer id) {
        LambdaQueryWrapper<Users> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Users::getUsersid, id);
        Users user = userService.getOne(wrapper);
        if (user != null) {
            return Result.ofSuccess(user);
        } else {
            return Result.ofFail(CommonErrorCode.DATA_NOT_FOUND);
        }
    }

    //登录
    @PostMapping("/login")
    public Result<Users> login(@RequestBody Users user) {
        try {
            //查询用户是否存在
            LambdaQueryWrapper<Users> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Users::getUsername, user.getUsername());
            Users users = userService.getOne(wrapper);
            if (users != null) {
                //判断密码是否正确
                if (users.getPassword().equals(user.getPassword())) {
                    return Result.ofSuccess(users);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Result.ofFail(CommonErrorCode.LOGIN_FAIL);
    }

    //注册
    @PostMapping("/register")
    public Result<String> register(@RequestBody Users user) {
        Integer i = 0;
        try{
            i = userService.registerUser(user);
        }catch (Exception e) {
            return Result.ofFail(CommonErrorCode.DATA_CONFLICT);
        }
        if (i > 0){
            return Result.ofSuccess();
        }
        return Result.ofFail(CommonErrorCode.FAILURE);
    }

    //修改账号信息
    @PostMapping("/update")
    public Result<Users> updateUserInfo(@RequestBody UserDto userDto) {
        System.out.println(userDto);
        try{
            LambdaQueryWrapper<Users> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(Users::getUsername, userDto.getUsername()).eq(Users::getPassword, userDto.getPassword());
            Users one = userService.getOne(wrapper);
            if(one != null) {
                //判断属性是否为空, 不为空则修改
                if (StrUtil.isNotBlank(userDto.getNickname())) one.setNickname(userDto.getNickname());
                if (StrUtil.isNotBlank(userDto.getEmail())) one.setEmail(userDto.getEmail());
                if (StrUtil.isNotBlank(userDto.getAvatarPath())) one.setAvatarPath(userDto.getAvatarPath());
                if (StrUtil.isNotBlank(userDto.getNewpassword())) one.setPassword(userDto.getNewpassword());
                BeanUtils.copyProperties(userDto,one);
            }
            userService.update(one,wrapper);
            return Result.ofSuccess();
        }catch (Exception e){
            return  Result.ofFail(CommonErrorCode.FAILURE);
        }
    }

}
