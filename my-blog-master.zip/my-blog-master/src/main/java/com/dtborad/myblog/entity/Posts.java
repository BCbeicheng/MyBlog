package com.dtborad.myblog.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 文章实体类
 */
@Data
@TableName("posts")
public class Posts implements Serializable {
    /**
     * @北城 文章ID
     */
    //@TableField("PostID")
    @TableId(value = "PostID", type = IdType.AUTO)
    private Integer postid;

    /**
     * @北城 标题
     */
    @TableField("Title")
    private String title;

    /**
     * @北城 作者ID
     */
    @TableField("AuthorID")
    private Integer authorid;

    /**
     * @北城 发布时间
     */
    @TableField("PublishTime")
    private Date publishtime;

    /**
     * @北城 标签
     */
    @TableField("Tags")
    private String tags;

    /**
     * @北城 点赞数
     */
    @TableField("Likes")
    private Integer likes;

    /**
     * @北城 内容
     */
    @TableField("Content")
    private String content;

    /**
     * 分类ID
     */
    @TableField("CategoryID")
    private Integer categoryid;
    /**
     * @北城 序列化ID
     */
    private static final long serialVersionUID = 1L;
}
