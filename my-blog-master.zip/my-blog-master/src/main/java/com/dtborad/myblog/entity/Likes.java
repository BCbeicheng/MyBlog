package com.dtborad.myblog.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 点赞实体类
 */
@Data
@TableName("likes")
public class Likes implements Serializable {
    /**
     * @北城
     * 点赞ID
     */
    //@TableField("LikeID")
    @TableId(value = "LikeID", type = IdType.AUTO)
    private Integer likeid;

    /**
     * @北城
     * 用户ID
     */
    @TableField("UserID")
    private Integer userid;

    /**
     * @北城
     * 文章ID
     */
    @TableField("PostID")
    private Integer postid;

    /**
     * @北城
     * 点赞时间
     */
    @TableField("LikeTime")
    private Date liketime;

    /**
     * @北城
     * 序列化ID
     */
    private static final long serialVersionUID = 1L;
}
