package com.dtborad.myblog.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 关注实体类
 */
@Data
@TableName("follows")
public class Follows implements Serializable {
    /**
     * @北城
     * 关注ID
     */
    //@TableField("FollowID")
    @TableId(value = "FollowID", type = IdType.AUTO)
    private Integer followid;

    /**
     * @北城
     * 关注者ID
     */
    @TableField("FollowerID")
    private Integer followerid;

    /**
     * @北城
     * 被关注者ID
     */
    @TableField("FolloweeID")
    private Integer followeeid;

    /**
     * @北城
     * 关注时间
     */
    @TableField("FollowTime")
    private Date followtime;

    /**
     * @北城
     * 序列化ID
     */
    private static final long serialVersionUID = 1L;
}
