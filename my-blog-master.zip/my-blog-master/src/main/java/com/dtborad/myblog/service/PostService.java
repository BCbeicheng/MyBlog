package com.dtborad.myblog.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.dtborad.myblog.entity.Posts;
import org.springframework.stereotype.Service;

import java.util.List;

public interface PostService extends IService<Posts> {
    //根据postId更新文章
    public Integer updatePostById(Posts posts);

    Page<Posts> getAllPostsByPageSize(Integer page, Integer pageSize, Integer categoryId, String content);
}
