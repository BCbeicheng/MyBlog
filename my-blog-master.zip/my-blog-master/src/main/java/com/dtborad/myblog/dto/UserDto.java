package com.dtborad.myblog.dto;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 用户实体类
 */
@Data
public class UserDto{
    private String usersid;
    private String username;
    private String password;
    private String email;
    private String nickname;
    private String avatarPath;
    private String newpassword;
    private String repassword;
    private Date registerTime;
}
