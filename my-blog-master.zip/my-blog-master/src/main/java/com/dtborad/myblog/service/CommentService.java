package com.dtborad.myblog.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.dtborad.myblog.entity.Comments;

public interface CommentService extends IService<Comments> {
}
