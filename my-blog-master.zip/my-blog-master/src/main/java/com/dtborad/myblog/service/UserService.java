package com.dtborad.myblog.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.dtborad.myblog.entity.Users;

public interface UserService extends IService<Users> {
    //注册用户
    Integer registerUser(Users user);
}
