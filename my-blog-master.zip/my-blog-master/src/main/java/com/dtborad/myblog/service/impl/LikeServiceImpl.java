package com.dtborad.myblog.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.dtborad.myblog.entity.Likes;
import com.dtborad.myblog.mapper.LikesMapper;
import com.dtborad.myblog.service.LikeService;
import org.springframework.stereotype.Service;

@Service
public class LikeServiceImpl extends ServiceImpl<LikesMapper, Likes> implements LikeService {
}
