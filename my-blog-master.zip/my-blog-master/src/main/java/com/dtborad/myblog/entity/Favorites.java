package com.dtborad.myblog.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 收藏实体类
 */
@Data
@TableName("favorites")
public class Favorites implements Serializable {
    /**
     * @北城
     * 收藏ID
     */
    //@TableField("FavoriteID")
    @TableId(value = "FavoriteID", type = IdType.AUTO)
    private Integer favoriteid;

    /**
     * @北城
     * 用户ID
     */
    @TableField("UserID")
    private Integer userid;

    /**
     * @北城
     * 文章ID
     */
    @TableField("PostID")
    private Integer postid;

    /**
     * @北城
     * 收藏时间
     */
    @TableField("FavoriteTime")
    private Date favoritetime;

    /**
     * @北城
     * 序列化ID
     */
    private static final long serialVersionUID = 1L;
}
