package com.dtborad.myblog.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 用户实体类
 */
@Data
@TableName("users")
public class Users implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 用户ID
     */
    //@TableField("UserID")
    @TableId(value = "UserID", type = IdType.AUTO)
    private String usersid;

    /**
     * 用户名
     */
    @TableField("Username")
    private String username;

    /**
     * 密码
     */
    @TableField("Password")
    private String password;
    /**
     * 昵称
     * */
    @TableField("NickName")
    private String nickname;
    /**
     * 电子邮箱
     */
    @TableField("Email")
    private String email;

    /**
     * 头像路径
     */
    @TableField("AvatarPath")
    private String avatarPath;

    /**
     * 注册时间
     */
    @TableField(value = "RegisterTime")
    private Date registerTime;
}
